export class Technology{
    id:number;
    name:String;
    toc:String;
    prerequisites:String;

    constructor(id:number,name:String,toc:String,prerequisites:String){
        this.id=id;
        this.name=name;
        this.toc=toc;
        this.prerequisites=prerequisites;
    }
}