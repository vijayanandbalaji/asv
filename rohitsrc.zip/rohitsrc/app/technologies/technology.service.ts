import { Injectable } from '@angular/core';
import { Technology } from './technology.model';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TechnologyService {

  commission: number = 10;
  commissionChanged = new Subject<number>();

  private technology: Technology[] = [
    new Technology(1, "Full Stack",
      "Be able to build ANY website you want Craft a portfolio of websites to apply for junior developer jobs Build fully - fledged websites and web apps for your startup or business Work as a freelance web developer Understand the latest frameworks and technologies, including Bootstrap 4, MongoDB, NodeJS, Express, Learn professional developer best practices",
      "No programming experience needed,A Mac or PC computer with access to the internet"),
    new Technology(2, "Angular",
      "Develop modern, complex, responsive and scalable web applications with Angular 8, Use their gained, deep understanding of the Angular 8 fundamentals to quickly establish themselves as frontend developers,Create single-page applications with one of the most modern JavaScript frameworks out there",
      "NO Angular 1 or Angular 2 knowledge is required!, Basic HTML and CSS knowledge helps, but isn't a must-have,Basic JavaScript knowledge is required"
    ),
    new Technology(3, "MongoDB",
      "Use MongoDB to its full potential in future projects, Use all features MongoDB offers you to work with data efficiently",
      "NO prior knowledge on databases (of any kind) is required,General web development or mobile development knowledge will help you but is not a must-have"),
  ]

  technologyChanged = new Subject<Technology[]>();
  constructor() { }

  getAllTechnology() {//returns all technology
    return this.technology.slice();
  }

  getTechByName(techName:String){//	@GetMapping(value = "/{name}")
    for(var tech of this.technology){
      if(tech.name===techName){
        return tech;
      }
    }
  }

  addNewTechnology(techname, toc, prerequisites) { //add the technology to the db
                                                  //@PostMapping("/add")
    this.technology.push(
      new Technology(4, techname, toc, prerequisites),
    )
    this.technologyChanged.next(this.technology)
    console.log(techname)
  }

  changeCommission(newCommission: number) {//###	@PutMapping("/{percentage}")
    this.commission = newCommission;
    this.commissionChanged.next(this.commission)
  }

 
}
