import { Trainers } from './trainers.model';

export class TrainerSkills {
    public
    id: number;
    mentor: Trainers;
    skillname: String;
    start_date: Date;
    end_date: Date;
    facility:String;
    fee: number;
    rating: number;

    constructor(id: number, mentor: Trainers, skillname: String, start_date: Date, end_date: Date,facility:String, fee: number, rating: number) {
        this.id = id;
        this.mentor = mentor;
        this.skillname = skillname;
        this.start_date = start_date;
        this.end_date = end_date;
        this.facility=facility;
        this.fee = fee;
        this.rating = rating;

    }
    
}   