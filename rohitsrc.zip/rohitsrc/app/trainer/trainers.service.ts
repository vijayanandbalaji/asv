import { Injectable } from '@angular/core';
import { Trainers } from './trainers.model';
import { ProfileService } from '../editprofile/profile.service';
import { Subject, Observable } from 'rxjs';
import { NgForm } from '@angular/forms';
import { TrainerSkills } from './trainerSkills.model';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class TrainersService {

  private mentor_url = 'http://localhost:9531/mentor';
  private skill_url = 'http://localhost:9531/skill';

  constructor(private http: HttpClient, private profileService: ProfileService) { }

  i: number = 0;
  private trainers: Trainers[] = [
    // new Trainers(1, "Arjun", "Arjun@gmail.com", "admin@123", 9952774728,
    //   "24:00-6:00", "https://udemy.com", "https://Arjun.com", 3, 1),
    // new Trainers(2, "Reddy", "Reddy@gmail.com", "admin@123", 9952774728,
    //   "6:00-12:00", "https://udemy.com", "https://Reddy.com", 2, 1),
    // new Trainers(3, "Joseph", "Joseph@gmail.com", "admin@123", 9952774728,
    //   "12:00-18:00", "https://udemy.com", "https://Joseph.com", 2, 1),
  ]
  trainerChanged = new Subject<Trainers[]>();

  private trainerSkills: TrainerSkills[] = [
    // new TrainerSkills(1, 1, "Angular", new Date(), new Date(), "Materials", 2000, 5),
    // new TrainerSkills(2, 2, "Full Stack", new Date(), new Date(), "Materials", 10000, 5),
    // new TrainerSkills(3, 3, "MongoDB", new Date(), new Date(), "Materials", 1000, 5),
  ];
  trainerSkillsChanged = new Subject<TrainerSkills[]>();

  searchText: String = '';
  searchTime: String = '';
  searchTextChanged = new Subject<String>();
  searchTimeChanged = new Subject<String>();

  signupTrainer(form: NgForm) {//	@PostMapping(value = "/create")
    const index: number = this.trainers.length + 1
    this.trainers.push(new Trainers(index, form.value.username,
      form.value.email, form.value.password, form.value.phone_number, form.value.timeslot,
      form.value.linkedinurl, form.value.mentor_profile, form.value.experience, 1))
    console.log("hey buddy new trainer added")
    console.log(this.trainers)
    this.trainerChanged.next(this.trainers)
    return this.trainers[(this.trainers.length - 1)];
  }

  updateTrainer(trainerId: number, form: NgForm) {
    let i: number = 0;
    for (var trainer of this.trainers) {
      if (trainer.id == trainerId) {
        this.trainers[i].name = form.value.username;
        this.trainers[i].password = form.value.password;
        this.trainers[i].email = form.value.email;
        this.trainers[i].phone_number = form.value.phone_number;
        this.trainers[i].timeslot = form.value.timeslot;
        this.trainers[i].linkedin_url = form.value.linkedinurl;
        this.trainers[i].mentor_profile = form.value.mentor_profile;
        this.trainers[i].experience = form.value.experience;

        this.trainerChanged.next(this.trainers)

        console.log(this.trainers)
        return;
      }
      i++;
    }
  }

  addTrainerSkills(trainerId: Trainers, techName: String, start_date: Date, end_date: Date, facility: String, fee: number) {//##here u should pass trainer obj itself instead of trainer id
    //	@PostMapping(value = "/create")
    //##add facility ####
    const index: number = this.trainerSkills.length + 1;
    this.trainerSkills.push(new TrainerSkills(index, trainerId, techName, start_date, end_date, facility, fee, 5));
    this.trainerSkillsChanged.next(this.trainerSkills)
    console.log(this.trainerSkills)
  }

  removeTrainerSkills(trainerId: number, skillId: number) {//##no neeed to pass trainerId, just pass SkillID
    //	@DeleteMapping(value = "/delete/{id}")

    let i: number = 0;
    for (var skill of this.trainerSkills) {
      if (skill.id == skillId && skill.mentor.id == trainerId) {
        this.trainerSkills.splice(i, 1)
        this.trainerSkillsChanged.next(this.trainerSkills)
        console.log(this.trainerSkills)
      }
      i++;
    }
  }

  checkLogin(email: String, password: String) {//	@GetMapping(value="/{email}/{password}")
    for (var user of this.trainers) {
      if ((user.email === email) && (user.password === password) && (user.access == 1)) {
        this.profileService.setCurrentSessionUser(user.id);
        return true;
      }
    }
    return false;
  }

  changeMentorAccess(value: number, mentorid: number) {//##	@PutMapping(value="/{id}/{access}")

    for (var mentor of this.trainers) {
      if (mentor.id == mentorid) {
        this.trainers[this.i].access = value;
        this.trainerChanged.next(this.trainers);
        console.log(this.trainers)
        break;
      }
      this.i++;
    }
    this.i = 0;
  }

  setSearchContent(techName: String, time: String) {
    this.searchText = techName;
    this.searchTime = time;
    this.searchTextChanged.next(this.searchText)
    this.searchTimeChanged.next(this.searchTime)
  }

  checkSearchContent(techName: String, time: String) {//this is used to check whether there is any seerch elemnt, return true if there is search element / else return false  
    var flag: number = 0;
    for (var trainer of this.trainers) {
      for (var skill of this.trainerSkills) {
        if (trainer.id == skill.mentor.id && skill.skillname === techName && trainer.timeslot === time && trainer.access == 1) {
          flag++;
        }
      }
    }
    if (flag > 0) { return true; }
    return false;
  }

  getTrainers(): Observable<any> {//	@GetMapping(value = "/mentors")

    return this.http.get(`${this.mentor_url}/mentors`);
    //return this.trainers.slice();
  }



  getTrainerById(userid: number) {//	@GetMapping(value = "/{id}")
    for (var user of this.trainers) {
      if (user.id == userid) {
        return user;
      }
    }
  }

  getTrainerSkills():Observable<any> {//	@GetMapping("/skills")
  return this.http.get(`${this.skill_url}/skills`); 
  // return this.trainerSkills.slice();
  }

  getTrainerSkillsById(skillid: number) {//	@GetMapping(value = "/{id}")
    for (var skill of this.trainerSkills) {
      if (skill.id == skillid) {
        return skill;
      }
    }
  }


}



// private trainers: Trainers[] = [
//   new Trainers(1, "Arjun", "Arjun@gmail.com", "admin@123", 9952774728, [new Trainertechnology(1, "Full Stack")
//     , new Trainertechnology(1, "MongoDB")],
//     "24:00-6:00", "materials", "https://udemy.com", 3),
//   new Trainers(2, "Reddy", "Reddy@gmail.com", "admin@123", 9952774728, [new Trainertechnology(2, "Angular")
//     , new Trainertechnology(2, "MongoDB")],
//     "6:00-12:00", "materials", "https://udemy.com", 2),
//   new Trainers(3, "Joseph", "Joseph@gmail.com", "admin@123", 9952774728, [new Trainertechnology(3, "React JS")
//     , new Trainertechnology(3, "Bootstrap")],
//     "12:00-18:00", "materials", "https://udemy.com", 2),
// ]
