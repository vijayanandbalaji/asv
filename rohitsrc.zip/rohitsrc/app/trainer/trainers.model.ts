export class Trainers{ //trainer model class
    public
        id:number;
        name:String;    
        email:String;
        password:String;
        phone_number:number;
        timeslot:String;
        linkedin_url:String;
        mentor_profile:String;
        experience:number;  
        access:number;
         

    constructor(id:number,name:String,email:String,password:String,
        phone_number:number,timeslot:String,linkedin_url:String,mentor_profile:String,experience:number,access:number){
            this.id=id;
            this.name=name;
            this.email=email;
            this.password=password;
            this.phone_number=phone_number;
            this.timeslot=timeslot;
            this.linkedin_url=linkedin_url;
            this.mentor_profile=mentor_profile;
            this.experience=experience;
            this.access=access;
        }    
}   


// export class Trainers{ //trainer model class
//     public
//         id:number;
//         name:String;    
//         email:String;
//         password:String;
//         phone_number:number;
//         technology:String;
//         timeslot:String;
//         facility:String;
//         url:String;
//         mentor_profile:String;
//         experience:number;
         

//     constructor(id:number,name:String,email:String,password:String,
//         phone_number:number,technology:String,timeslot:String,
//         facility:String,url:String,mentor_profile:String,experience:number){
//             this.id=id;
//             this.name=name;
//             this.email=email;
//             this.password=password;
//             this.phone_number=phone_number;
//             this.technology=technology;
//             this.timeslot=timeslot;
//             this.facility=facility;
//             this.url=url;
//             this.mentor_profile=mentor_profile;
//             this.experience=experience;
//         }    
// }   
