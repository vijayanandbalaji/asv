import { Component, OnInit } from '@angular/core';
import { TrainersService } from '../trainers.service';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { Trainers } from '../trainers.model';
import { ProposalsService } from 'src/app/proposals/proposals.service';
import { TrainerSkills } from '../trainerSkills.model';
import { Technology } from 'src/app/technologies/technology.model';
import { TechnologyService } from 'src/app/technologies/technology.service';
import { UserService } from 'src/app/user/user.service';
import { ProfileService } from 'src/app/editprofile/profile.service';

@Component({
  selector: 'app-trainer-details',
  templateUrl: './trainer-details.component.html',
  styleUrls: ['./trainer-details.component.css']
})
export class TrainerDetailsComponent implements OnInit {
  id: number;
  skillid: number;
  trainers: Trainers;
  allTrainerSkill: TrainerSkills[];
  trainerSkill: TrainerSkills;
  technology: Technology;
  user: any;
  constructor(private trainerService: TrainersService, private route: ActivatedRoute, private router: Router,
    private proposalService: ProposalsService, private techService: TechnologyService,
    private userService:UserService,private profileService:ProfileService) { }

  ngOnInit() {
    this.id = this.route.snapshot.params['id'];
    this.skillid = this.route.snapshot.params['skillid'];

    this.route.params.subscribe(
      (params: Params) => {
        this.id = +params['id'];
        this.skillid = +params['skillid']
        this.detailsInit();
      }
    );
      
 this.detailsInit();
  }

  detailsInit() {
    this.user=this.userService.getStudentById(this.profileService.currentSessionUserId)//subscribe to change
    this.trainers = this.trainerService.getTrainerById(this.id);//	@GetMapping(value = "/{id}")
    this.trainerSkill = this.trainerService.getTrainerSkillsById(this.skillid)//	@GetMapping(value = "/{id}")
    this.allTrainerSkill = this.trainerService.getTrainerSkills();//	@GetMapping("/skills")
    this.trainerService.trainerSkillsChanged.subscribe(
      (skill: TrainerSkills[]) => {
        this.allTrainerSkill = skill;
      }
    )
    this.technology = this.techService.getTechByName(this.trainerSkill.skillname)//	@GetMapping(value = "/{name}")
  }

  //create a new Object for Proposals DB and push it sendProposal()------------------------------------
  //====================================================================================================
  sendProposal() {
    this.proposalService.sendProposal(this.user,this.trainers,this.trainerSkill);//forcefully sends default proposal which is gn in sendProposal fn of prposalService
        //@PostMapping("/send") -->send userProposal object itself
    this.router.navigate(['/progress']);
  }


} 
