import { Component, OnInit, OnDestroy } from '@angular/core';
import { ProposalsService } from 'src/app/proposals/proposals.service';
import { Proposals } from 'src/app/proposals/proposals.model';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-trainer-status',
  templateUrl: './trainer-status.component.html',
  styleUrls: ['./trainer-status.component.css']
})
export class TrainerStatusComponent implements OnInit, OnDestroy {
  private subscription: Subscription;
  proposal: Proposals[];
  constructor(private proposalService: ProposalsService) { }

  ngOnInit() {
    this.proposal = this.proposalService.getProposals();//###########change to getProposalsByMentorID(mentorID)
      //	@GetMapping(value="/mentor/{mentorid}")
    this.subscription = this.proposalService.mainProposalChanged.subscribe(
      (proposalChanged: Proposals[]) => {
        this.proposal = proposalChanged;
      }
    )
  }

  acceptProposal(proposalid: number) {//	@PutMapping(value="/status/{id}/{status}")
    this.proposalService.proposalStatus(proposalid, 1);//1 represents accept..here we set accept
    this.proposalService.emptyProposals();
    this.ngOnInit()
  }

  rejectProposal(proposalid: number) {//	@PutMapping(value="/status/{id}/{status}")
    this.proposalService.proposalStatus(proposalid, 0);//1 represents reject..here we set rejection
    this.proposalService.emptyProposals();
    this.ngOnInit()
  }

  ngOnDestroy() {
    this.proposalService.emptyProposals();
    this.subscription.unsubscribe();
  }
}
