import { User } from '../user/user.modal';
import { Trainers } from '../trainer/trainers.model';
import { TrainerSkills } from '../trainer/trainerSkills.model';

export class Payment {//acts like purchase db
    public
    id: number;
    user: User;
    user_name: String;
    mentor: Trainers;
    mentor_name: String;
    mentorSkills: TrainerSkills;
    technology: String;
    fee: number;
    progress: number;

    constructor(id: number, user: User, user_name: String, mentor: Trainers, mentor_name: String, mentorSkills: TrainerSkills, technology: String, fee: number, progress: number) {
        this.id = id;
        this.user = user;
        this.user_name = user_name;
        this.mentor = mentor;
        this.mentor_name = mentor_name;
        this.mentorSkills = mentorSkills;
        this.technology = technology;
        this.fee = fee;
        this.progress = progress;
    }
}   