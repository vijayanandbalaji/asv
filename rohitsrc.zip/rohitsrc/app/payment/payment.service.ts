import { Injectable } from '@angular/core';
import { Payment } from './payment.model';
import { ProposalsService } from '../proposals/proposals.service';
import { Proposals } from '../proposals/proposals.model';
import { Subject } from 'rxjs';
import { User } from '../user/user.modal';
import { Trainers } from '../trainer/trainers.model';
import { TrainerSkills } from '../trainer/trainerSkills.model';

@Injectable({
  providedIn: 'root'
})
export class PaymentService {
  payment: Payment[] = [];//contains all the course(both completed and on going)
  tempProposal: Proposals;
  user: User;
  user_name: String;
  mentor: Trainers;
  mentor_name: String;
  mentorSkills: TrainerSkills;
  technology: String;
  fee:number;
  progress: number;
  i: number = 0;
  userPurchase: Payment[] = [];//this contains all purchased courses( on going course)
  userPurchaseChanged = new Subject<Payment[]>();
  completedCourse: Payment[] = [];//this contains all completed course
  completedCourseChanged = new Subject<Payment[]>();

  constructor(private proposalService: ProposalsService) { }

  pay(proposalid) {

    const index: number = this.payment.length + 1;
    this.tempProposal = this.proposalService.getproposalIdToPay(proposalid);//#########get the proposal by using proposalId
                                                                            //####then pass the proposal object to paymentController in body
                                                                            //	@PostMapping(value = "/purchase")

    this.user = this.tempProposal.user;
    this.user_name = this.tempProposal.user_name;
    this.mentor = this.tempProposal.mentor;
    this.mentor_name = this.tempProposal.mentor_name;
    this.mentorSkills = this.tempProposal.mentorSkills;
    this.technology = this.tempProposal.technology;
    this.fee=this.tempProposal.fee;
    this.progress = this.tempProposal.progress;

    this.payment.push(new Payment(index, this.user, this.user_name, this.mentor, this.mentor_name, this.mentorSkills, this.technology, this.fee, this.progress));
    console.log(this.payment)

    this.proposalService.removeProposal(proposalid);//####after payment delete the proposal from proposal DB by proposalId
                                                    //@DeleteMapping(value="/delete/{proposal_id}")
            
  }

  getPurchasedCourses(userid: number) {
    this.userPurchase = []
//###here get all purchased course and then separate b/w ongoing and purchased courses (create a new tab for purchased course)
    for (var payment of this.payment) {
      if (payment.user.id == userid && payment.progress < 100) {
        this.userPurchase.push(payment);
        this.userPurchaseChanged.next(this.userPurchase);
      }
    }
    return this.userPurchase
  }

  getCompletedCourses(userid: number) {
    this.completedCourse = []
    for (var payment of this.payment) {
      if (payment.user.id == userid && payment.progress == 100) {
        this.completedCourse.push(payment)
        this.completedCourseChanged.next(this.completedCourse)
      }
    }
    return this.completedCourse;
  }

  changeProgress(purchaseId: number, progressValue: number) {

    for (var payment of this.payment) {

      if (payment.id == purchaseId && payment.progress < 100) {
        console.log("inside chnge progress --pay service" + this.i)
        console.log(payment.id)
        this.payment[this.i].progress = progressValue;
        console.log(this.payment)
        this.i = 0;
        return;
      }
      this.i++;
    }
    this.i = 0;
  }

}
