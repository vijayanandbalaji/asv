import { Component, OnInit } from '@angular/core';
import { Trainers } from '../trainer/trainers.model';
import { TrainerSkills } from '../trainer/trainerSkills.model';
import { TrainersService } from '../trainer/trainers.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  trainers: Observable<Trainers[]>;
  trainerSkills: TrainerSkills[];

  search: boolean = false;
  searchText: String = '';
  searchTime: String = '';
 
  constructor(private trainerService: TrainersService) { }

  ngOnInit() {
    this.trainers = this.trainerService.getTrainers();
    // this.trainerService.trainerChanged.subscribe(
    //   (trainer: Trainers[]) => {
    //     this.trainers = trainer
    //   }
    // )

    this.trainerSkills = this.trainerService.getTrainerSkills();
    this.trainerService.trainerSkillsChanged.subscribe(
      (skill: TrainerSkills[]) => {
        this.trainerSkills = skill;
      }
    )

    this.searchText = this.trainerService.searchText;//this fn is used to get the search text from the trainer service which is set by header.comp.ts
    this.searchTime = this.trainerService.searchTime;//this fn is used to get the search time from the trainer service which is set by header.comp.ts

    this.trainerService.searchTextChanged.subscribe(
      (text: String) => {
        this.searchText = text;

      }
    )
    this.trainerService.searchTimeChanged.subscribe(
      (time: String) => {
        this.searchTime = time;
        this.check();
      }
    )

    this.check();
  }

  check() {
    this.search=false;
    if (this.trainerService.checkSearchContent(this.searchText, this.searchTime)) { //this fn checks whther there are data with the defined searchtxt and timing
      this.changeSearchTrue()                                                       //if there it returns true / else false
    }
  }

  changeSearchTrue() {
    this.search = true;
  }

  ngOnDestroy() {
  }
}
