import { Injectable } from '@angular/core';
import { Admin } from './admin.model';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
 currentSessionAdmin:number;
 currentSessionAdminChanged=new Subject<number>();

  private admin: Admin[] = [
    new Admin(1, "admin", "admin@gmail.com", "admin@123"),
  ]
  constructor() { }

  
  checkLogin(email: String, password: String) {
    for (var admin of this.admin) {
      if ((admin.email === email) && (admin.password === password)) {
        this.currentSessionAdmin=admin.id;
        this.currentSessionAdminChanged.next(this.currentSessionAdmin)
        return true;
      }
    } 
    return false;
  }
}
