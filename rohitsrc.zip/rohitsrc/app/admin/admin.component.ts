import { Component, OnInit } from '@angular/core';
import { AdminService } from './admin.service';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  validlogin:boolean=false;
  constructor(private adminService: AdminService,private router:Router) { }

  ngOnInit() {
  }
  onSubmit(form: NgForm) {

    this.validlogin = this.adminService.checkLogin(form.value.email, form.value.password);//this is to check only admin login
                                                                                          //	@GetMapping(value="/{email}/{password}")
    if (this.validlogin) {
      this.router.navigate(['/adminUpdation/technology']);
    }

  }
}
