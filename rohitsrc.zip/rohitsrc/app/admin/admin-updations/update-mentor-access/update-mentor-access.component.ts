import { Component, OnInit } from '@angular/core';
import { Trainers } from 'src/app/trainer/trainers.model';
import { TrainersService } from 'src/app/trainer/trainers.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-update-mentor-access',
  templateUrl: './update-mentor-access.component.html',
  styleUrls: ['./update-mentor-access.component.css']
})
export class UpdateMentorAccessComponent implements OnInit {
  trainers:Observable<Trainers[]>;

  constructor(private trainerService:TrainersService) { }

  ngOnInit() {
    this.trainers=this.trainerService.getTrainers();
     
  }

  changeAccess(value:number,mentorid:number){//##	@PutMapping(value="/{id}/{access}")

    this.trainerService.changeMentorAccess(value,mentorid);
  }
 

}
