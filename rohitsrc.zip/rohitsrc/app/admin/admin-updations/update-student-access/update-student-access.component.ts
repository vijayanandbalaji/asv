import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/user/user.modal';
import { UserService } from 'src/app/user/user.service';

@Component({
  selector: 'app-update-student-access',
  templateUrl: './update-student-access.component.html',
  styleUrls: ['./update-student-access.component.css']
})
export class UpdateStudentAccessComponent implements OnInit {
student:User[];

  constructor(private userService:UserService) { }

  ngOnInit() {
    this.student=this.userService.getAllStudent();
    this.userService.usersChanged.subscribe(
      (student:User[])=>{
        this.student=student;
      }
    )
  }

  changeAccess(value:number,studentid:number){//	@PutMapping(value="/{id}/{access}")

    this.userService.changeStudentAccess(value,studentid);
  }
 

}
