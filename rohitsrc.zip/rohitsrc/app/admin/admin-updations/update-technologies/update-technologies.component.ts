import { Component, OnInit } from '@angular/core';
import { TechnologyService } from 'src/app/technologies/technology.service';
import { Technology } from 'src/app/technologies/technology.model';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-update-technologies',
  templateUrl: './update-technologies.component.html',
  styleUrls: ['./update-technologies.component.css']
})
export class UpdateTechnologiesComponent implements OnInit {

  technology: Technology[];
  constructor(private techService: TechnologyService) { }

  ngOnInit() {
    this.technology = this.techService.getAllTechnology();
    this.techService.technologyChanged.subscribe(
      (techChanged:Technology[])=>{
        this.technology=techChanged;
      }
    )
  } 

  onSubmit(form: NgForm) {
     this.techService.addNewTechnology(form.value.technologyname,form.value.toc, form.value.prerequisites);//@PostMapping("/add")
     form.resetForm();     
    
  }

  onCommissionChange(form:NgForm){//	@PutMapping("/{percentage}")
    this.techService.changeCommission(form.value.commission)
     form.resetForm();  
  }

}
