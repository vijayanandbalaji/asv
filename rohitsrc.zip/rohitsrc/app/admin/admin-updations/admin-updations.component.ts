import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-updations',
  templateUrl: './admin-updations.component.html',
  styleUrls: ['./admin-updations.component.css']
})
export class AdminUpdationsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
