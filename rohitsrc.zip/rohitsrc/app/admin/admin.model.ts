export class Admin{
    public  
        id:number;
        name:String;
        email:String;
        password:String;
       

        constructor(id:number,name:String,email:String,password:String ){
            this.id=id;
            this.name=name;
            this.email=email;
            this.password=password;
             
        }
}