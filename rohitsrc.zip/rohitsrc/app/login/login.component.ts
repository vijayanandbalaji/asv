import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UserService } from '../user/user.service';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ProfileService } from '../editprofile/profile.service';
import { TrainersService } from '../trainer/trainers.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  validlogin: boolean = false;
  constructor(private userService: UserService, private router: Router, private route: ActivatedRoute,
    private profileService: ProfileService, private trainerService: TrainersService) { }

  mentor: boolean;
  student: boolean;

  ngOnInit() {
    if (this.route.snapshot.params['user'] === "student") {
      this.profileService.setCurrentUser(this.route.snapshot.params['user']);
    } else {
      this.profileService.setCurrentUser(this.route.snapshot.params['user']);
    }

    this.route.params.subscribe(
      (params: Params) => {
        if (params['user'] === "student") {
          this.profileService.setCurrentUser(this.route.snapshot.params['user']);
          this.initUser()
        }
        else {
          this.profileService.setCurrentUser(this.route.snapshot.params['user']);
          this.initUser()
        }
      }
    );

    if (this.profileService.getCurrentUser() === "student") {
      this.student = true;
      this.mentor = false
    } else {
      this.mentor = true;
      this.student = false;
    }
  }

  
  initUser() {
    if (this.profileService.getCurrentUser() === "student") {
      this.student = true;
      this.mentor = false
    } else {
      this.mentor = true;
      this.student = false;
    }
  }

  onSubmit(form: NgForm) {
    if (this.student) {
      this.validlogin = this.userService.checkLogin(form.value.email, form.value.password);//this is to check only user login
                                                                                          //	@GetMapping(value="/{email}/{password}")
      if (this.validlogin) {
        this.router.navigate(['/']);
      }
    }
    if (this.mentor) {
      this.validlogin = this.trainerService.checkLogin(form.value.email, form.value.password);//this is to check only trainer login
                                                                                              // /	@GetMapping(value="/{email}/{password}")
      if (this.validlogin) {
        this.router.navigate(['/']);
      }
    }
  }
}
