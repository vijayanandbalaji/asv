import { Component, OnInit } from '@angular/core';
import { TrainersService } from '../trainer/trainers.service';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor(private trainerService:TrainersService,private router:Router) { }

  ngOnInit() {
  }
  
  onSearch(form:NgForm){
this.trainerService.setSearchContent(form.value.search,form.value.timeslot);
this.router.navigate(['/search']);
form.reset();
  }
}
