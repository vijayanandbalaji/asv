import { Injectable } from '@angular/core';
import { User } from './user.modal';
import { Subject } from 'rxjs';
import { ProfileService } from '../editprofile/profile.service';
import { NgForm } from '@angular/forms';


@Injectable({
  providedIn: 'root'
})
export class UserService {
  constructor(private profileService: ProfileService) { }

  i: number = 0;
  private users: User[] = [
    // new User(1, "Rohit", "admin@123", "rohitadittya@gmail.com", 9952774728, 1),
    // new User(2, "Adittya", "admin@123", "adittya@gmail.com", 9952774728, 0),
  ]
  usersChanged = new Subject<User[]>();

  signupUser(form: NgForm) {//	@PostMapping(value="/create")
    const index: number = this.users.length + 1
    this.users.push(new User(index, form.value.username, form.value.password, form.value.email, form.value.phone_number, 1))
    console.log(this.users)
  }

  updateUser(stuId: number, form: NgForm) {
    let i: number = 0;
    for (var stu of this.users) {
      if (stu.id == stuId) {  
        this.users[i].name = form.value.username;
        this.users[i].password = form.value.password;
        this.users[i].email = form.value.email;
        this.users[i].phone_number = form.value.phone_number;
        this.usersChanged.next(this.users)
      console.log(this.users) 
      return;
      }
      i++;
    }
  }

  checkLogin(email: String, password: String) {//	@GetMapping(value="/{email}/{password}")
    for (var user of this.users) {
      if ((user.email === email) && (user.password === password)) {
        this.profileService.setCurrentSessionUser(user.id);
        return true;
      }
    }
    return false;
  }

  getAllStudent() {
    return this.users.slice()
  }

  getStudentById(userid: number) {
    for (var user of this.users) {
      if (user.id == userid) {
        return user;
      }
    }
  }

  changeStudentAccess(value: number, studentid: number) {//##	@PutMapping(value="/{id}/{access}")

    for (var student of this.users) {
      if (student.id == studentid) {
        this.users[this.i].access = value;
        this.usersChanged.next(this.users);
        console.log(this.users)
        break;
      }
      this.i++;
    }
    this.i = 0;
  }

}
