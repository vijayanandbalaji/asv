export class User { //user model class
    public
    id: number;
    name: String;
    password: String;
    email: String;
    phone_number: number;
    access: number;
    constructor(id: number, name: String, password: String, email: String, phone_number: number, access: number) {
        this.id = id;
        this.name = name;
        this.password = password;
        this.email = email;
        this.phone_number = phone_number;
        this.access = access
    }
}               