import { Component, OnInit, OnDestroy } from '@angular/core';
import { TrainersService } from '../trainer/trainers.service';
import { Trainers } from '../trainer/trainers.model';
import { TrainerSkills } from '../trainer/trainerSkills.model';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {

  trainers: Observable<Trainers[]>;
  trainerSkills: Observable<TrainerSkills[]>;

  constructor(private trainerService: TrainersService) { }

  ngOnInit() {
    // this.trainers = this.trainerService.getTrainers();//	@GetMapping(value = "/mentors")
    // this.trainerService.trainerChanged.subscribe(
    //   (trainer: Trainers[]) => {
    //     this.trainers = trainer 
    //     console.log(this.trainers)
    //   }
    // )

    // this.trainerSkills = this.trainerService.getTrainerSkills();//	@GetMapping("/skills")
    // this.trainerService.trainerSkillsChanged.subscribe(
    //   (skill: TrainerSkills[]) => {
    //     this.trainerSkills = skill;
    //   }
    // )

    this.homepageInit();
  }

  homepageInit() {
    this.trainers = this.trainerService.getTrainers();//	@GetMapping(value = "/mentors")
    this.trainerSkills = this.trainerService.getTrainerSkills();//	@GetMapping("/skills")
  }


}
