import { Injectable } from '@angular/core';
import { Proposals } from './proposals.model';
import { Subject } from 'rxjs';
import { User } from '../user/user.modal';
import { Trainers } from '../trainer/trainers.model';
import { TrainerSkills } from '../trainer/trainerSkills.model';

@Injectable({
  providedIn: 'root'
})
export class ProposalsService {

  constructor() { }

  private proposals: Proposals[] = []

  mainProposal: Proposals[] = [];//this array is jst to store cpy or push some elemnts into them nd return to calling fn
  mainProposalChanged = new Subject<Proposals[]>();

  i: number = 0;
  tempproposal: Proposals[] = [];//this is temp proposal used to store the proposed data by student and is used in getProposal(userID)
  tempproposalChanged = new Subject<Proposals[]>();//update whne there is change in tempproposal array

  acceptedProposal: Proposals[] = [];//this is used to store temporarily the data of accepted proposals
  acceptedProposalChanged = new Subject<Proposals[]>();//this handles changes in accepted proposal

  emptyProposals() { //this fn empties all temporary arrays everytime the comp is destroyed or else it keeps on pushing into existing array with same data
    this.mainProposal = [];
    this.mainProposalChanged.next(this.mainProposal)
    this.tempproposal = [];
    this.tempproposalChanged.next(this.tempproposal)
    this.acceptedProposal = [];
    this.acceptedProposalChanged.next(this.acceptedProposal)
  }

  getProposals() {//this fn is called by trainer-status comp to get all the proposals
  
    for (var proposal of this.proposals) {
      if (proposal.status == 2) {
        this.mainProposal.push(proposal)
        this.mainProposalChanged.next(this.mainProposal)
      }
    }
    return this.mainProposal;
  }

  getProposal(userid: number) {//this fn is used to handle the proposed tab in progress component--->used to store the proposed
    // request sent by user to mentor but not yet to be accpted/rejected by mentor
    for (var proposal of this.proposals) {
      if (proposal.user.id == userid && proposal.status == 2) {
        this.tempproposal.push(proposal);
        this.tempproposalChanged.next(this.tempproposal)
      }
    }
    return this.tempproposal;
  }

  getProposalAcceptance(userid: number) {//this fn used to return the accepted proposals 

    for (var proposal of this.proposals) {
      if (proposal.user.id == userid && proposal.status == 1) {
        this.acceptedProposal.push(proposal);
        this.acceptedProposalChanged.next(this.acceptedProposal)

      }
    }
    return this.acceptedProposal;
  }

  getproposalIdToPay(proposalId: number) { //this fn used for payment and is called by payment service, returns particular userid cart info
    for (var proposal of this.proposals) {
      if (proposal.id == proposalId) {
        return proposal;
      }
    }

  }

  proposalStatus(id: number, value: number) { //this fn is called by trainer-status comp, used to either accept/reject proposal
    //	@PutMapping(value="/status/{id}/{status}")
    for (var proposal of this.proposals) {
      if (proposal.id == id) {
        proposal.status = value;
        this.tempproposal = [];//evry time the trainer accpts/rejects the tempproposal arry gets empty..it will initialized with values at the time when progress comp call getProposal(curr user)
        this.tempproposalChanged.next(this.tempproposal)
      }
    } 
  }

  sendProposal(user:User,trainers:Trainers,trainerSkill:TrainerSkills) { //called by trainer-details comp, used to send the prposal to trainer
      //	@PostMapping("/send") -->send userProposal object itself
    this.proposals.push(new Proposals(1, user, user.name, trainers, trainers.name,trainerSkill, trainerSkill.skillname,trainerSkill.fee, 2, 0))
    console.log(this.proposals)

  }

  removeProposal(proposalId: number) {
    for (var proposal of this.proposals) {
      if (proposal.id == proposalId) {
        this.proposals.splice(this.i, 1)
        this.acceptedProposalChanged.next(this.acceptedProposal)
      }
      this.i++;
    }
    this.i = 0;
  }
}
