import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { HomepageComponent } from './homepage/homepage.component';
import { RouterModule } from '@angular/router';
import { TrainerDetailsComponent } from './trainer/trainer-details/trainer-details.component';
import { TrainerStatusComponent } from './trainer/trainer-status/trainer-status.component';
import { ProgressComponent } from './progress/progress.component';
import { EditprofileComponent } from './editprofile/editprofile.component';
import { AdminComponent } from './admin/admin.component';
import { AdminUpdationsComponent } from './admin/admin-updations/admin-updations.component';
import { UpdateTechnologiesComponent } from './admin/admin-updations/update-technologies/update-technologies.component';
import { UpdateStudentAccessComponent } from './admin/admin-updations/update-student-access/update-student-access.component';
import { UpdateMentorAccessComponent } from './admin/admin-updations/update-mentor-access/update-mentor-access.component';
import { SearchComponent } from './search/search.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    LoginComponent,
    SignupComponent,
    HomepageComponent,
    TrainerDetailsComponent,
    TrainerStatusComponent,
    ProgressComponent,
    EditprofileComponent,
    AdminComponent,
    AdminUpdationsComponent,
    UpdateTechnologiesComponent,
    UpdateMentorAccessComponent,
    UpdateStudentAccessComponent,
    SearchComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterModule.forRoot([
      { path: '', component: HomepageComponent },
      { path: 'admin', component: AdminComponent },
      { path: 'adminUpdation', component: AdminUpdationsComponent,children:[
        {path:'mentoraccess',component:UpdateMentorAccessComponent},
        {path:'studentaccess',component:UpdateStudentAccessComponent},
        {path:'technology',component:UpdateTechnologiesComponent}
      ]},
      { path: 'mentor/:id/:skillid', component: TrainerDetailsComponent },
      { path: 'login/:user', component: LoginComponent },
      { path: 'signup/:user', component: SignupComponent },
      { path: 'proposals', component: TrainerStatusComponent },
      { path: 'progress', component: ProgressComponent },
      { path: 'editprofile', component: EditprofileComponent },
      {path:'search',component:SearchComponent}
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
