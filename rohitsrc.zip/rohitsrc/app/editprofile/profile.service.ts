import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {
private currentuser:String;//stores whether trainer or student
currentuserChanged=new Subject<String>();

currentSessionUserId:number;// this acts like session, it contains current logged user's id(either trainer or student)
currentSessionUserIdChanged=new Subject<number>();

  constructor() { }

  setCurrentSessionUser(userid:number){
    this.currentSessionUserId=userid;// this acts like session, it contains current logged user's id
    this.currentSessionUserIdChanged.next(this.currentSessionUserId)
  }

  setCurrentUser(user:String){//stores whether trainer or student
    this.currentuser=user;
    this.currentuserChanged.next(this.currentuser);
  }


  getCurrentUser(){
     return this.currentuser;
  }
}
