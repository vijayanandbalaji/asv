import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ProfileService } from './profile.service';
import { UserService } from '../user/user.service';
import { User } from '../user/user.modal';
import { TrainersService } from '../trainer/trainers.service';
import { TrainerSkills } from '../trainer/trainerSkills.model';
import { NgForm, FormGroup } from '@angular/forms';
import { Technology } from '../technologies/technology.model';
import { TechnologyService } from '../technologies/technology.service';
import { Trainers } from '../trainer/trainers.model';

@Component({
  selector: 'app-editprofile',
  templateUrl: './editprofile.component.html',
  styleUrls: ['./editprofile.component.css']
})
export class EditprofileComponent implements OnInit {

  constructor(private route: ActivatedRoute, private profileService: ProfileService, private userService: UserService, private trainerService: TrainersService,
    private techService: TechnologyService) { }

  currentUserId: number;//this contains current logged in user id, it is retrieved from user.service
  mentor: boolean;
  student: boolean;
  user: User;//student
  trainer: Trainers;//trainer
  userSkills: TrainerSkills[];
  tempTechArray = [];//this is used to temporarily store trainer updated skills which will thn be updated in original trainer skill
  tech: Technology[];


  ngOnInit() {

    if (this.profileService.getCurrentUser() === "student") {
      this.student = true;
      this.mentor = false
    } else {
      this.mentor = true;
      this.student = false;
    }

    this.currentUserId = this.profileService.currentSessionUserId;
    this.profileService.currentSessionUserIdChanged.subscribe(
      (userid: number) => {
        this.currentUserId = userid;
      }
    )

    if (this.student) {
      this.user = this.userService.getStudentById(this.currentUserId);
    }
    if (this.mentor) {
      this.trainer = this.trainerService.getTrainerById(this.currentUserId);
      this.userSkills = this.trainerService.getTrainerSkills();
      this.trainerService.trainerSkillsChanged.subscribe(
        (skill: TrainerSkills[]) => {
          this.userSkills = skill;
        }
      )
    }

    this.tech = this.techService.getAllTechnology();
    this.techService.technologyChanged.subscribe(
      (tech: Technology[]) => { this.tech = tech; }
    )

  }


  update(form: NgForm) {
    if (this.student) {
      this.userService.updateUser(this.currentUserId, form) //##edit profile of user, edit using user_id and user object
                                                            //	@PutMapping(value="/{id}") --->send user obj in req body
      console.log(form.value)
    }
    if (this.mentor) {
      this.trainerService.updateTrainer(this.currentUserId, form);//##edit profile of mentor, edit using mentor_id and mentor object
                                                                  //	@PutMapping(value = "/{id}")

      console.log("entering into adding skills area")
      console.log(form.value)
      for (var a of this.tempTechArray) {
        this.trainerService.addTrainerSkills(this.trainer, a.technologyname, a.start_date,a.end_date,a.facilities, a.fee);//## here u should pass current user object itself instead of id
                                              //dont forget to add facility in constructor
                                              //	@PostMapping(value = "/create")
      }

      this.tempTechArray = [];
    }
  }

  addTechnology(form: NgForm) { //this fn is used to push the trainer skills into temporary array which is then passed through 
    this.tempTechArray.push(form.value) //addTrainerSkills(this.trainerId,a.technologyname,a.duration,a.fee) fn
    form.reset();
    // $("#closeButton").trigger('click');

  }

  removeTech(index: number, check: String, skillId: number) {//this is used to remove the existing trainers technology and also temp trainer technology
    if (check === "existing") {
      this.trainerService.removeTrainerSkills(this.currentUserId, skillId)//##no need to pass currentuserid, just pass skillId to remove the skill
                                                                        //	@DeleteMapping(value = "/delete/{id}")
                                                                        //##remove currentUserId
    }
    if (check === "temp") {
      this.tempTechArray.splice(index,1)
    }
  }



}
