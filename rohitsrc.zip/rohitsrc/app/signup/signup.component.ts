import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { ProfileService } from '../editprofile/profile.service';
import { UserService } from '../user/user.service';
import { TechnologyService } from '../technologies/technology.service';
import { Technology } from '../technologies/technology.model';
import { NgForm } from '@angular/forms';
import { TrainersService } from '../trainer/trainers.service';
import { Trainers } from '../trainer/trainers.model';
@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})

export class SignupComponent implements OnInit {
  mentor: boolean;
  student: boolean;
  tech: Technology[];
  trainerId: Trainers;
  tempTechArray = [];


  constructor(private route: ActivatedRoute, private profileService: ProfileService, private techService: TechnologyService,
    private trainerService: TrainersService, private userService: UserService) { }

  ngOnInit() {
    if (this.route.snapshot.params['user'] === "student") {
      this.profileService.setCurrentUser(this.route.snapshot.params['user']);
    } else {
      this.profileService.setCurrentUser(this.route.snapshot.params['user']);
    }

    this.route.params.subscribe(
      (params: Params) => {
        if (params['user'] === "student") {
          this.profileService.setCurrentUser(this.route.snapshot.params['user']);
          this.initUser();
        }
        else {
          this.profileService.setCurrentUser(this.route.snapshot.params['user']);
          this.initUser();
        }
      }
    );

    if (this.profileService.getCurrentUser() === "student") {
      this.student = true;
      this.mentor = false
    } else {
      this.mentor = true;
      this.student = false;
    }

    this.tech = this.techService.getAllTechnology();
    this.techService.technologyChanged.subscribe(
      (tech: Technology[]) => {
        this.tech = tech;
      }
    )
  }

  initUser() {
    if (this.profileService.getCurrentUser() === "student") {
      this.student = true;
      this.mentor = false
    } else {
      this.mentor = true;
      this.student = false;
    }
  }

  signup(form: NgForm) {  
    if (this.student) {
      this.userService.signupUser(form) //	@PostMapping(value="/create")
    }
    if (this.mentor) {
      this.trainerId = this.trainerService.signupTrainer(form);//this fn returns trainer id
                                                              //	@PostMapping(value = "/create")
      console.log("entering into adding skills area")
      for (var a of this.tempTechArray) {
                                        //%%%%%send mentor ref itself instead of mentor id%%%%%%%........... 
                                        //add facility in constructor,,, dont forget
        this.trainerService.addTrainerSkills(this.trainerId, a.technologyname, a.start_date,a.end_date,a.facilities, a.fee);//	@PostMapping(value = "/create")
      }

    }
  }

  addTechnology(form: NgForm) { //this fn is used to push the trainer skills into temporary array which is then passed through 
     this.tempTechArray.push(form.value) //addTrainerSkills(this.trainerId,a.technologyname,a.duration,a.fee) fn
     form.reset();
    // $("#closeButton").trigger('click');
     
  }

  removeAddedTech(index:number){
    this.tempTechArray.splice(index,1)
  }
}
