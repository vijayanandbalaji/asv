import { Component, OnInit, OnDestroy } from '@angular/core';
import { Proposals } from '../proposals/proposals.model';
import { ProposalsService } from '../proposals/proposals.service';
import { PaymentService } from '../payment/payment.service';
import { Subscription } from 'rxjs';
import { Payment } from '../payment/payment.model';

@Component({
  selector: 'app-progress',
  templateUrl: './progress.component.html',
  styleUrls: ['./progress.component.css']
})
export class ProgressComponent implements OnInit, OnDestroy {
  proposal: Proposals[];//contains only proposed req which neither accptd/rejected by trainer
  acceptedproposal: Proposals[];//contain only proposal req which are accptd by trainer
  purchasedCourses: Payment[];
  completedCourses: Payment[];

  tempsubscription: Subscription;
  acceptsubscription: Subscription;
  purchasesubcription: Subscription;
  courseCompleteSubscription: Subscription;
  constructor(private proposalService: ProposalsService, private payService: PaymentService) { }

  ngOnInit() {

    this.proposal = this.proposalService.getProposal(1);//this handles getting all user proposed req that are 
                                                        //neither accpted/rejected by mentor (initially sending 1st user forcefully)
                                                        //here we should pass userid and it retrieves proposal by UserId
                                                        //@GetMapping(value="/user/{userid}")
    this.tempsubscription = this.proposalService.tempproposalChanged.subscribe(
      (proposal: Proposals[]) => {
        this.proposal = proposal;
      }
    )

    this.acceptedproposal = this.proposalService.getProposalAcceptance(1);//this handles getting all user proposed req that
                                                                        // are accpted  (initially sending 1st user forcefully)
                                                                        //@GetMapping(value="/user/{user_id}/accepted")

    this.acceptsubscription = this.proposalService.acceptedProposalChanged.subscribe(
      (acceptedProposal: Proposals[]) => {
        this.acceptedproposal = acceptedProposal;
      }
    )

    this.purchasedCourses = this.payService.getPurchasedCourses(1); //this handles all the purchased courses  (initially sending 1st user forcefully)
                                                                    //###get purchased courses by userID
                                                                    //	@GetMapping(value="/user/{user_id}")
                                                                    //create a separate tab for purchased course and ongoing course

    this.purchasesubcription = this.payService.userPurchaseChanged.subscribe(
      (changedPurchase: Payment[]) => {
        this.purchasedCourses = changedPurchase;
       }
    )

    this.completedCourses=this.payService.getCompletedCourses(1);//this handles in providing all the completed course of specified user
                                                                //@GetMapping(value="/user/{user_id}/completed")
    this.courseCompleteSubscription=this.payService.completedCourseChanged.subscribe(
      (completed:Payment[])=>{
        this.completedCourses=completed;
      }
    )
  }

  pay(proposalid: number) {
     this.payService.pay(proposalid);//forcefully makes payment which is gn in pay fn of payment service;
                                    //@PostMapping(value = "/purchase")
    this.proposalService.emptyProposals();
    this.ngOnInit()
  }
  progressUpdate(purchaseId:number,value:number){
    console.log("inside update fn") 
    this.payService.changeProgress(purchaseId,value);
    this.ngOnInit()
  }
  ngOnDestroy() {
    this.proposalService.emptyProposals(); //this array is used to empty the temporary arrays when leaving the component or else
    this.tempsubscription.unsubscribe();
    this.acceptsubscription.unsubscribe();
    this.purchasesubcription.unsubscribe();
    this.courseCompleteSubscription.unsubscribe();

  }

  
}
