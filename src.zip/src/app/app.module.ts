import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { RouterModule } from '@angular/router';
import { UserLoginComponent } from './user-login/user-login.component';

import { MentorLoginComponent } from './mentor-login/mentor-login.component';
import { UserSignupComponent } from './user-signup/user-signup.component';
import { MentorSignupComponent } from './mentor-signup/mentor-signup.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    UserLoginComponent,
    MentorLoginComponent,
    UserSignupComponent,
    MentorSignupComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    RouterModule.forRoot([
      { path: '', component: HeaderComponent , pathMatch:'full' },
      {path:'userlogin',component:UserLoginComponent},
      {path:'mentorlogin',component:MentorLoginComponent},
      {path:'usersignup',component:UserSignupComponent},
      {path:'mentorsignup',component:MentorSignupComponent}
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
